/*
 * Main.c
 *
 *  Created on: 26/gen/2014
 *      Author: atti
 */

#define ARDUINO
#define ARDUINO_MAIN
#include "Arduino.h"

#include <XMC1100.h>		//SFR declarations of the selected device
#include <DAVE3.h>

// #include Arduino HEADER FILES.
#include "pins_arduino.h"
#include "wiring_digital.h"
#include "wiring_time.h"
#include "wiring_clock.h"

/**
 * @brief This function will transmit the input data to PC Hyperterminal
 *
 * @param[in]: p start address of character buffer
 * @return void
 * */
void uart_printf(const char *p)
{
	while(*p){
		while( 0 != ((UART001_Handle0.UartRegs->TRBSR) & (USIC_CH_TRBSR_TFULL_Msk)));
		UART001_WriteData(UART001_Handle0,*p);
		p++;
	}

}


int main(void)
{

	 /*
	  *  Periferals Initialization
	  */
	DAVE_Init();
	//----PIN-SETUP-------------------------------------------------------------------------------------
	P1_2_set_mode(OUTPUT_OD_AF7);
	P1_3_set_mode(INPUT);
	//--------------------------------------------------------------------------------------------------

	wiring_digital_init();
	wiring_analog_init();


#if !defined(ARDUINO)
	uint32_t time = 0;

	// To use XMC1x00 Board without Arduino, simply put your code here.
	/* Send hello world to PC hyper terminal - 19200 baud */
	{
	uint32_t status = 0;
	uint8_t data[] = "ARDUINO by XMC1100";

		status = UART001_WriteDataMultiple(&UART001_Handle0, (uint16_t*)&data, (uint32_t)sizeof(data)/2);
		if(status == 11)
		 {
			 /* data transmitted */
		 }
	}

	// Set Time
	setTime(23,34,11, 03,02,2014);

	// For example: LED toggling
	pinMode(13, OUTPUT);
	while (1)
	{
		time = millis();
		toggleLED();
		pinMode(A1, INPUT);
		analogRead(A1);
		delay(500);
		pinMode(A1, INPUT_PULLUP);
		analogRead(A1);
		delay(500);
		pinMode(A1, INPUT_PULLDW);
		analogRead(A1);
		time = second();
		uart_printf(dayStr(day()));
		uart_printf("atti \n");
	}

	return 0;


#else
	// Arduino's main() function just calls setup() and loop()....
	setup();
	while (1) {
		loop();
		//yield();
	}
#endif
}
//****************************************************************************
// 							       ARDUINO SKETCH
//****************************************************************************

/*
  Blink
  Turns on an LED on for one second, then off for one second, repeatedly.

  This example code is in the public domain.
 */

// Pin 13 has an LED connected on most Arduino boards.
// Pin 13 has the LED on XMC1100
// give it a name:
int led = 13;

// the setup routine runs once when you press reset:
void setup() {
  // initialize the digital pin as an output.
  pinMode(led, OUTPUT);
}

// the loop routine runs over and over again forever:
void loop() {
  digitalWrite(led, HIGH);   // turn the LED on (HIGH is the voltage level)
  delay(1000);               // wait for a second
  digitalWrite(led, LOW);    // turn the LED off by making the voltage LOW
  delay(1000);               // wait for a second
}

//****************************************************************************
// 							       END OF FILE
//****************************************************************************

