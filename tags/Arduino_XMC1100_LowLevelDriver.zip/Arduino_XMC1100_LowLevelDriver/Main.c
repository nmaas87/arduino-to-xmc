/*
 * Main.c
 *
 *  Created on: Apr 8, 2014
 *      Author: neote
 */

/* This code uses the CCU40.41 Slice as a timer to create a microsecond delay function.
 * Function can work from 10us onwards. Needs to be further callibrated.
 */



#include <DAVE3.h>			//Declarations from DAVE3 Code Generation (includes SFR declaration)
uint32_t microsec;

__IO uint32_t *Timervalue;
__IO uint32_t *CCU4TimerStart;
__IO uint32_t *CCU4TimerStopClear;
__IO uint32_t *CCU4Idlemode;
__O uint32_t *IOOMR;

void Delay_usec(uint32_t uiUs);

int main(void)
{
	DAVE_Init();			// Initialization of DAVE Apps

	// Initialisation of variables and register2variables setup
	Timervalue			= &PWMSP001_Handle0.CC4yRegsPtr->TIMER;
	CCU4TimerStart		= &PWMSP001_Handle0.CC4yRegsPtr->TCSET;
	CCU4TimerStopClear	= &PWMSP001_Handle0.CC4yRegsPtr->TCCLR;
	CCU4Idlemode		= &PWMSP001_Handle0.CC4yKernRegsPtr->GIDLC;
	//IOOMR				= &IO004_Handle0.PortRegs->OMR;

	// Start the PWM counter
	*CCU4Idlemode |=0x08;

	while(1)
	{
		Delay_usec(10);
		//		*IOOMR |= 0x0400040;
	}

}

void Delay_usec(uint32_t uiUs)
{
status_t Status;

	// Start the PWM counter
	Status = PWMSP001_Start((PWMSP001_HandleType*)&PWMSP001_Handle0);

	uint32_t delaycount, temp_Timer;

	delaycount = (uiUs-4)*64;
	temp_Timer = *Timervalue;

	*CCU4TimerStart		|= 0x01; //Start CCU timer

	while(temp_Timer < delaycount)
	{
		temp_Timer = *Timervalue;
	}

	*CCU4TimerStopClear	|= 0x03;//Stop CCU timer
}
