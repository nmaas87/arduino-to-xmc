package CodeGenerator;

import java.util.*;
import com.ifx.davex.appjetinteract.App2JetInterface;

public class ccu4globalc_template
{
  protected static String nl;
  public static synchronized ccu4globalc_template create(String lineSeparator)
  {
    nl = lineSeparator;
    ccu4globalc_template result = new ccu4globalc_template();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + NL + "/*CODE_BLOCK_BEGIN[CCU4GLOBAL.c]*/" + NL + "" + NL + "" + NL + "/*******************************************************************************" + NL + " Copyright (c) 2011, Infineon Technologies AG                                 **" + NL + " All rights reserved.                                                         **" + NL + "                                                                              **" + NL + " Redistribution and use in source and binary forms, with or without           **" + NL + " modification,are permitted provided that the following conditions are met:   **" + NL + "                                                                              **" + NL + " *Redistributions of source code must retain the above copyright notice,      **" + NL + " this list of conditions and the following disclaimer.                        **" + NL + " *Redistributions in binary form must reproduce the above copyright notice,   **" + NL + " this list of conditions and the following disclaimer in the documentation    **" + NL + " and/or other materials provided with the distribution.                       **" + NL + " *Neither the name of the copyright holders nor the names of its contributors **" + NL + " may be used to endorse or promote products derived from this software without**" + NL + " specific prior written permission.                                           **" + NL + "                                                                              **" + NL + " THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS \"AS IS\"  **" + NL + " AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE    **" + NL + " IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE   **" + NL + " ARE  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   **" + NL + " LIABLE  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         **" + NL + " CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF         **" + NL + " SUBSTITUTE GOODS OR  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    **" + NL + " INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN      **" + NL + " CONTRACT, STRICT LIABILITY,OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)       **" + NL + " ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE   **" + NL + " POSSIBILITY OF SUCH DAMAGE.                                                  **" + NL + "                                                                              **" + NL + " To improve the quality of the software, users are encouraged to share        **" + NL + " modifications, enhancements or bug fixes with Infineon Technologies AG       **" + NL + " dave@infineon.com).                                                          **" + NL + "                                                                              **" + NL + "********************************************************************************" + NL + "**                                                                            **" + NL + "**                                                                            **" + NL + "** PLATFORM : Infineon XMC4000/XMC1000 Series                                 **" + NL + "**                                                                            **" + NL + "** COMPILER : Compiler Independent                                            **" + NL + "**                                                                            **" + NL + "** AUTHOR   : App Developer                                                   **" + NL + "**                                                                            **" + NL + "** MAY BE CHANGED BY USER [yes/no]: Yes                                       **" + NL + "**                                                                            **" + NL + "** MODIFICATION DATE : January 25, 2013                                       **" + NL + "**                                                                            **" + NL + "*******************************************************************************/" + NL + "/*******************************************************************************" + NL + "**                      Author(s) Identity                                    **" + NL + "********************************************************************************" + NL + "**                                                                            **" + NL + "** Initials     Name                                                          **" + NL + "** ---------------------------------------------------------------------------**" + NL + "** KS           App Developer                                                 **" + NL + "**                                                                            **" + NL + "*******************************************************************************/" + NL + "" + NL + "/**" + NL + " * @file  CCU4GLOBAL.c" + NL + " *" + NL + " * @brief This file contains implementations of all Public and Private functions" + NL + " *        of CCU4GLOBAL App." + NL + " */" + NL + "/* Revision History" + NL + " * 22 March     2012   v1.0.0    Initial version" + NL + " * 17 September 2012   v1.0.4    code to disable clock gating for XMC44 devices" + NL + " * 25 January   2013   v1.0.10   code to disable clock gating for XMC1xxx devices" + NL + " */" + NL + "/*******************************************************************************" + NL + "**                      Include Files                                         **" + NL + "*******************************************************************************/" + NL + "" + NL + "#include \"../../inc/CCU4GLOBAL/CCU4GLOBAL.h\"" + NL + "" + NL + "/*******************************************************************************" + NL + "**                 Public Function declarations                              **" + NL + "*******************************************************************************/" + NL + "/**" + NL + " * @cond INTERNAL_DOCS" + NL + " */" + NL + "" + NL + "void CCU4GLOBAL_Init(void)" + NL + "{" + NL + "  static uint32_t CCU4InitCalled = (uint32_t)0;" + NL + "  if(CCU4InitCalled == (uint32_t)0)" + NL + "  {" + NL + "    CCU4InitCalled = (uint32_t)1;" + NL + "    /*" + NL + "     * Each instance of the App brings the module out of reset and enable the prescalar clock" + NL + "     */";
  protected final String TEXT_2 = "  " + NL + "    /* Initialise the clock */";
  protected final String TEXT_3 = NL + "    CLK001_Init();        ";
  protected final String TEXT_4 = NL + "    CLK002_Init();";
  protected final String TEXT_5 = "  ";
  protected final String TEXT_6 = "  " + NL + "    /* Disables the gating for CCU4 kernel */      " + NL + "    /*This is applicable for XMC4400,XMC4200 and XMC1xxx Devices*/";
  protected final String TEXT_7 = NL + "    if (!((uint32_t)SCU_CLK->CGATCLR0 & (uint32_t)SCU_CLK_CGATCLR0_CCU4";
  protected final String TEXT_8 = "_Pos)){ " + NL + "    SCU_GENERAL->PASSWD = 0x000000C0UL;" + NL + "    WR_REG(SCU_CLK->CLKCR, SCU_CLK_CLKCR_CNTADJ_Msk, SCU_CLK_CLKCR_CNTADJ_Pos,CLK002_DELAYCNT);" + NL + "    SET_BIT(SCU_CLK->CGATCLR0, SCU_CLK_CGATCLR0_CCU4";
  protected final String TEXT_9 = "_Pos);" + NL + "    while ((uint32_t)SCU_CLK->CLKCR & (uint32_t)SCU_CLK_CLKCR_VDDC2LOW_Msk)" + NL + "    {" + NL + "    \t    ;" + NL + "    }" + NL + "    SCU_GENERAL->PASSWD = 0x000000C3UL;" + NL + "    }";
  protected final String TEXT_10 = NL + "    SET_BIT(SCU_CLK->CGATCLR0, SCU_CLK_CGATCLR0_CCU4";
  protected final String TEXT_11 = "_Pos);";
  protected final String TEXT_12 = NL + "    SET_BIT(SCU_CLK->CGATCLR1, SCU_CLK_CGATCLR1_CCU4";
  protected final String TEXT_13 = "_Pos);";
  protected final String TEXT_14 = NL + "    ";
  protected final String TEXT_15 = " " + NL + "    /* Deassert the peripheral */" + NL + "    /*This is applicable for XMC4500, XMC4400 and XMC4200 Devices*/";
  protected final String TEXT_16 = NL + "    RESET001_DeassertReset(PER1_CCU4";
  protected final String TEXT_17 = ");";
  protected final String TEXT_18 = NL + "    RESET001_DeassertReset(PER0_CCU4";
  protected final String TEXT_19 = ");";
  protected final String TEXT_20 = NL + "    " + NL + "    /* Sets Run bit of the Prescalar */" + NL + "    SET_BIT(CCU4Global_Handle";
  protected final String TEXT_21 = ".CC4yKernRegsPtr->GIDLC,CCU4_GIDLC_SPRB_Pos);";
  protected final String TEXT_22 = " //This app is not mapped to any CCU4 Module ";
  protected final String TEXT_23 = "  " + NL + "    " + NL + "  }" + NL + "}" + NL + "" + NL + "" + NL + "/**" + NL + " * @endcond" + NL + " */" + NL + "/*CODE_BLOCK_END*/";
  protected final String TEXT_24 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     App2JetInterface app = (App2JetInterface) argument; 
    stringBuffer.append(TEXT_1);
     int Is44Device = -1; 
     int Is42Device = -1; 
     int Is45Device = -1; 
     int Is1xDevice = -1; 
     Is45Device = ((app.getSoftwareId().substring(0,2).compareTo("45")==0)?1:0); 
     Is44Device = ((app.getSoftwareId().substring(0,2).compareTo("44")==0)?1:0); 
     Is42Device = ((app.getSoftwareId().substring(0,2).compareTo("42")==0)?1:0); 
     Is1xDevice = ((app.getSoftwareId().substring(0,1).compareTo("1")==0)?1:0); 
    stringBuffer.append(TEXT_2);
     if((Is45Device==1)||(Is44Device==1)||(Is42Device==1)) { 
    stringBuffer.append(TEXT_3);
     } else { 
    stringBuffer.append(TEXT_4);
    } 
    stringBuffer.append(TEXT_5);
     String AppBaseuri = "app/ccu4global/"; 
     String kernelNo = null; 
     String SliceUri = null; 
     String temp = "3"; 
     String appInst  = null; 
     ArrayList<String> appsList = (ArrayList<String>)(app.getApps("app/ccu4global/"));
    for (String appIns : appsList ) {
    	appInst = appIns.substring(appIns.lastIndexOf("/")+1);
     SliceUri = app.getMappedUri(AppBaseuri + appInst +"/global"); 
     if ((SliceUri != null) && (SliceUri.trim() != "")) { 
     kernelNo = SliceUri.substring(SliceUri.indexOf("/ccu4")+6,SliceUri.indexOf("/global")); 
    if ((Is44Device==1)||(Is42Device==1)||(Is1xDevice==1))
    {
    stringBuffer.append(TEXT_6);
     if(Integer.parseInt(kernelNo) <=2) { 
    if (Is1xDevice==1){ 
    stringBuffer.append(TEXT_7);
    stringBuffer.append(kernelNo);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(kernelNo);
    stringBuffer.append(TEXT_9);
     } else { 
    stringBuffer.append(TEXT_10);
    stringBuffer.append(kernelNo);
    stringBuffer.append(TEXT_11);
    } 
     } else { 
    stringBuffer.append(TEXT_12);
    stringBuffer.append(kernelNo);
    stringBuffer.append(TEXT_13);
    } 
    }
    stringBuffer.append(TEXT_14);
    if ((Is45Device==1)||(Is44Device==1)||(Is42Device==1))
    {
    stringBuffer.append(TEXT_15);
     if(kernelNo.equals(temp)) { 
    stringBuffer.append(TEXT_16);
    stringBuffer.append(kernelNo);
    stringBuffer.append(TEXT_17);
     } else { 
    stringBuffer.append(TEXT_18);
    stringBuffer.append(kernelNo);
    stringBuffer.append(TEXT_19);
     } 
     } 
    stringBuffer.append(TEXT_20);
    stringBuffer.append(appInst);
    stringBuffer.append(TEXT_21);
    } 
    else {
    stringBuffer.append(TEXT_22);
    }
    }
    stringBuffer.append(TEXT_23);
    stringBuffer.append(TEXT_24);
    return stringBuffer.toString();
  }
}
