package CodeGenerator;

import java.util.*;
import com.ifx.davex.appjetinteract.App2JetInterface;

public class nvic_sr101_confh_template
{
  protected static String nl;
  public static synchronized nvic_sr101_confh_template create(String lineSeparator)
  {
    nl = lineSeparator;
    nvic_sr101_confh_template result = new nvic_sr101_confh_template();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = " ";
  protected final String TEXT_2 = NL + NL + "/* CODE_BLOCK_BEGIN[NVIC_SR101_Conf.h] */" + NL + "/******************************************************************************" + NL + " *" + NL + " * Copyright (C) 2012 Infineon Technologies AG. All rights reserved." + NL + " *" + NL + " * Infineon Technologies AG (Infineon) is supplying this software for use with " + NL + " * Infineon's microcontrollers." + NL + " * This file can be freely distributed within development " + NL + " * tools that are supporting such microcontrollers. " + NL + " *" + NL + " * THIS SOFTWARE IS PROVIDED \"AS IS\".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED" + NL + " * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF" + NL + " * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE." + NL + " * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR" + NL + " * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER." + NL + " *" + NL + "********************************************************************************" + NL + "**                                                                            **" + NL + "**                                                                            **" + NL + "** PLATFORM : Infineon XMC1000 Series                                         **" + NL + "**                                                                            **" + NL + "** COMPILER : Compiler Independent                                            **" + NL + "**                                                                            **" + NL + "** AUTHOR : App Developer                                                     **" + NL + "**                                                                            **" + NL + "** MAY BE CHANGED BY USER [yes/Yes]: Yes                                      **" + NL + "**                                                                            **" + NL + "** MODIFICATION DATE : Feb 04, 2013                                           **" + NL + "**                                                                            **" + NL + "*******************************************************************************/" + NL + "/*******************************************************************************" + NL + "**                       Author(s) Identity                                   **" + NL + "********************************************************************************" + NL + "**                                                                            **" + NL + "** Initials    Name                                                           **" + NL + "** ---------------------------------------------------------------------------**" + NL + "** SK          App Developer                                                  **" + NL + "*******************************************************************************/" + NL + " ";
  protected final String TEXT_3 = NL + "/**" + NL + "  * @App Version NVIC_SR101_CONF_H <";
  protected final String TEXT_4 = ">" + NL + "  * " + NL + "  * @file   NVIC_SR101_Conf.h" + NL + "  *" + NL + "  * @brief  This file has the App instance configurations." + NL + "  *" + NL + "  */" + NL + "/* Revision History */" + NL + "/* 31-01-13 v0.1.0 Inital version" + NL + " * 04-02-13 v0.1.3 App version added" + NL + " */" + NL + " #ifndef NVIC_SR101_CONF_H_" + NL + " #define NVIC_SR101_CONF_H_" + NL + " " + NL + "/**" + NL + " * @}" + NL + " */" + NL + "" + NL + "#endif /* NVIC_SR101_CONF_H*/" + NL + "/*CODE_BLOCK_END*/";
  protected final String TEXT_5 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
     App2JetInterface app = (App2JetInterface) argument; 
    stringBuffer.append(TEXT_2);
     String AppBaseuri = "app/nvic_sr101/0"; 
    stringBuffer.append(TEXT_3);
    stringBuffer.append(app.getAppVersion(AppBaseuri) );
    stringBuffer.append(TEXT_4);
    stringBuffer.append(TEXT_5);
    return stringBuffer.toString();
  }
}
