/*
 * Main.c
 *
 *  Created on: 20/apr/2014
 *      Author: atti
 */





#include <DAVE3.h>			//Declarations from DAVE3 Code Generation (includes SFR declaration)


int main(void)
{
//	status_t status;		// Declaration of return variable for DAVE3 APIs (toggle comment if required)


	DAVE_Init();			// Initialization of DAVE Apps


	while(1)
	{

	}
	return 0;
}
