
// @Module        HD44780 LCD controller
// @Filename      HD44780.C
// @Project       distancemeter.dav
//----------------------------------------------------------------------------
// @Controller    Infineon XE164F-96F66
//
// @Compiler      Keil
//
// @Codegenerator DAvE 2.0 Compatible
//
// @Description   This file contains low level functions to drive an LCD display based on HD44780 controller.
//
//----------------------------------------------------------------------------
// @Date          15/05/2009 11.45.26
//
//****************************************************************************


//****************************************************************************
// @Project Includes
//****************************************************************************
#include "HD44780.h"


//****************************************************************************
// @Macros
//****************************************************************************


//****************************************************************************
// @Defines
//****************************************************************************
//  Display Size Defines
#define DISPLAY_NCHAR 20
#define DISPLAY_NLINE 4


//****************************************************************************
// @Typedefs
//****************************************************************************


//****************************************************************************
// @Imported Global Variables
//****************************************************************************


//****************************************************************************
// @Local Variables
//****************************************************************************
uint8_t _rs_pin; 			// LOW: command.  HIGH: uint8_tacter.
uint8_t _rw_pin; 			// LOW: write to LCD.  HIGH: read from LCD.
uint8_t _enable_pin; 		// activated by a HIGH pulse.
uint8_t _data_pins[8];


//****************************************************************************
// @External Prototypes
//****************************************************************************


//****************************************************************************
// @Prototypes Of Local Functions
//****************************************************************************
void LCDwait60cycles(void);
void LCD_write8bits(uint8_t value);
void LCDwriteCtrl(uint8_t command);				   // interface emulation over a port
void LCDwriteData(uint8_t data);					   // interface emulation over a port


//****************************************************************************
// @Function      LCDinit
//
//----------------------------------------------------------------------------
// @Description   initialize HD44780
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    None
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************

void LCDinit(uint8_t fourbitmode, uint8_t rs, uint8_t rw, uint8_t enable,
			 uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3,
			 uint8_t d4, uint8_t d5, uint8_t d6, uint8_t d7)
{
  _rs_pin = rs;
  _rw_pin = rw;
  _enable_pin = enable;

  _data_pins[0] = d0;
  _data_pins[1] = d1;
  _data_pins[2] = d2;
  _data_pins[3] = d3;
  _data_pins[4] = d4;
  _data_pins[5] = d5;
  _data_pins[6] = d6;
  _data_pins[7] = d7;

  pinMode(_rs_pin, OUTPUT);

  // we can save 1 pin by not using RW. Indicate by passing 255 instead of pin#
	if (_rw_pin != 255) pinMode(_rw_pin, OUTPUT);

  pinMode(_enable_pin, OUTPUT);

  LCDinitialize();
}


//****************************************************************************
// @Function      LCDtest
//
//----------------------------------------------------------------------------
// @Description   Test the correct functioning of displaly
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    None
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDtest(void)
{
	char check1[] = {0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff};
	char check2[] = {0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80, 0xff, 0x80};
	LCDgoToPos(1,1);
	LCDwriteString(check1);
	LCDgoToPos(2,1);
	LCDwriteString(check2);
	LCDgoToPos(3,1);
	LCDwriteString(check1);
	LCDgoToPos(4,1);
	LCDwriteString(check2);
	LCDwait60cycles();
	LCDgoToPos(1,1);
	LCDwriteString(check2);
	LCDgoToPos(2,1);
	LCDwriteString(check1);
	LCDgoToPos(3,1);
	LCDwriteString(check2);
	LCDgoToPos(4,1);
	LCDwriteString(check1);
	LCDwait60cycles();
	LCDclear();
}


//****************************************************************************
// @Function     LCDinitialize
//
//----------------------------------------------------------------------------
// @Description   Inizialize LCD display, this fuction is the first routine to call
//			sets the control port and the data port
//
// When the display powers up, it is configured as follows:
//
// 1. Display clear
// 2. Function set:
//    DL = 1; 8-bit interface data
//    N = 0; 1-line display
//    F = 0; 5x8 dot uint8_tacter font
// 3. Display on/off control:
//    D = 0; Display off
//    C = 0; Cursor off
//    B = 0; Blinking off
// 4. Entry mode set:
//    I/D = 1; Increment by 1
//    S = 0; No shift
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    None
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************

void LCDinitialize(void)
{
	LCD_write8bits(0x00);
	digitalWrite(_rs_pin, LOW);
	if (_rw_pin != 255) digitalWrite(_rw_pin, LOW);
	digitalWrite(_enable_pin, HIGH);
	delay(20);
	LCDwriteCtrl(0x38); //function set
	delay(10);
	LCDwriteCtrl(0x38); //function set
	delay(1);
	LCDwriteCtrl(0x08); //disp off
	delay(1);
	LCDwriteCtrl(0x06); //entry mode set
	delay(1);
	LCDwriteCtrl(0x01); //display clear
	delay(10);
	LCDwriteCtrl(0x0c); //disp on
	delay(1);
}

//****************************************************************************
// @Function     LCDdispON
//
//----------------------------------------------------------------------------
// @Description   turn on the display
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    None
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDdispON(void)
{
	LCDwriteCtrl(0x0C); //disp on
	delay(1);
}

//****************************************************************************
// @Function     LCDdispOFF
//
//----------------------------------------------------------------------------
// @Description   turn off the display
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    None
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDdispOFF(void)
{
	LCDwriteCtrl(0x08); //disp off
	delay(1);
}

//****************************************************************************
// @Function     LCDwriteChar
//
//----------------------------------------------------------------------------
// @Description   Write a Char
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters   	Character to be written
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDwriteChar(char pchar)
{
	LCDwriteData(pchar);
}

//****************************************************************************
// @Function     LCDwriteString
//
//----------------------------------------------------------------------------
// @Description   Write  a string
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    	String to be written
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDwriteString(char *string)
{
uint8_t inx=0;

	while(string[inx] != '\0')
	{
		LCDwriteChar(string[inx]);
		inx++;
	}
}



//****************************************************************************
// @Function     LCDhome
//
//----------------------------------------------------------------------------
// @Description   Return curson its original position
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    None
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDhome(void)
{
	LCDwriteCtrl(LCD_RETURNHOME); //send clear and return home command
	delay(10);
}

//****************************************************************************
// @Function     LCDclear
//
//----------------------------------------------------------------------------
// @Description   Clear all display
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    None
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDclear(void)
{
	LCDwriteCtrl(LCD_CLEARDISPLAY); //send clear command
	delay(10);
}

//****************************************************************************
// @Function     LCDgoToPos
//
//----------------------------------------------------------------------------
// @Description   place the cursor at position
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    Line Number and Char position number
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDgoToPos(uint8_t line, uint8_t pchar) //connected display is 4 x 20
{
	switch (line) // use set DDRAM address command
	{ // lines order: 1 3 2 4
		case 1:
			LCDwriteCtrl(0x80+pchar-1);
			break;
		case 2:
			LCDwriteCtrl(0xC0+pchar-1);
			break;
		case 3:
			LCDwriteCtrl(0x94+pchar-1);
			break;
		case 4:
			LCDwriteCtrl(0xD4+pchar-1);
			break;
		default: break;
	}
}

#if 0
//****************************************************************************
// @Function     LCDdefineChar
//
//----------------------------------------------------------------------------
// @Description   create  custom uint8_tacter
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    custom uint8_tacters number and bytes of data
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDdefineChar(uint8_t uint8_tNo, uint8_t data[8])
{
	uint8_t i;
	LCDwriteCtrl(0x40 + (uint8_tNo << 3)); // set CGRAM address command
	for(i = 0 ; i < 8 ; i++) LCDwriteData(data[i]);
}
#endif


/************ low level data pushing commands **********/
//****************************************************************************
// @Function      LCDwait60cycles
//
//----------------------------------------------------------------------------
// @Description   wait 60 CPU cycles (it runs properly with CPU at 66MHz)
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    None
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************

void LCDwait60cycles(void)
{
volatile uint8_t i;

    for (i = 0 ; i < 60 ; i++)
    {
    	asm("mov r0,r0");
    }
}

//****************************************************************************
// @Function     LCDwriteCtrl
//
//----------------------------------------------------------------------------
// @Description   send to display the control command
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    control command
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDwriteCtrl(uint8_t command)
{
	LCDwait60cycles();
	LCD_write8bits(command);
	LCDwait60cycles();
    if (_rw_pin != 255) digitalWrite(_rw_pin, LOW); // RW is low for the writing
	LCDwait60cycles();
	digitalWrite(_rs_pin, LOW); 					// RS low for commands
	LCDwait60cycles();
	digitalWrite(_enable_pin, HIGH); 				// E high
	delay(1);
	//	delayMicroseconds(1);    // enable pulse must be >450ns
	digitalWrite(_enable_pin, LOW); 				// E low
	delayMicroseconds(100);   						// commands need > 37us to settle
}

//****************************************************************************
// @Function     LCDwriteData
//
//----------------------------------------------------------------------------
// @Description   write to display the given uint8_tacter (data)
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    data
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCDwriteData(uint8_t data)
{
    //LCDwait60cycles();
	LCD_write8bits(data);
    LCDwait60cycles();
    if (_rw_pin != 255) digitalWrite(_rw_pin, LOW); // RW is low for the writing
    LCDwait60cycles();
    digitalWrite(_rs_pin, HIGH); 					// RS is high for data
    LCDwait60cycles();
	digitalWrite(_enable_pin, HIGH); 				// E high
	delay(1);
//	delayMicroseconds(1);    // enable pulse must be >450ns
	digitalWrite(_enable_pin, LOW); 				// E low
	delayMicroseconds(100);   						// commands need > 37us to settle
}

/*
void LCD_pulseEnable(void) {
	digitalWrite(_enable_pin, LOW);
	delayMicroseconds(1);
	digitalWrite(_enable_pin, HIGH);
	delayMicroseconds(1);    // enable pulse must be >450ns
	digitalWrite(_enable_pin, LOW);
	delayMicroseconds(100);   // commands need > 37us to settle
}

void LCD_write4bits(uint8_t value) {
  for (int i = 0; i < 4; i++) {
    pinMode(_data_pins[i], OUTPUT);
    digitalWrite(_data_pins[i], (value >> i) & 0x01);
  }
}
*/

//****************************************************************************
// @Function     LCD_write8bits
//
//----------------------------------------------------------------------------
// @Description   write to display the given 8-bits
//
//----------------------------------------------------------------------------
// @Returnvalue   None
//
//----------------------------------------------------------------------------
// @Parameters    data
//
//----------------------------------------------------------------------------
// @Date          21/05/2009
//
//****************************************************************************
void LCD_write8bits(uint8_t value)
{
	for (int i = 0; i < 8; i++)
	{
		pinMode(_data_pins[i], OUTPUT);
		digitalWrite(_data_pins[i], (value >> i) & 0x01);
	}
}

//****************************************************************************
// 							       END OF FILE
//****************************************************************************
