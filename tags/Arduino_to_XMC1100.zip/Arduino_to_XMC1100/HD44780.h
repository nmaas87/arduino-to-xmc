//****************************************************************************
// @Module        HD44780 LCD controller
// @Filename      HD44780.H
// @Project       distancemeter.dav
//----------------------------------------------------------------------------
// @Controller    Infineon XE164F-96F66
//
// @Compiler      Keil
//
// @Codegenerator DAvE 2.0 Compatible
//
// @Description   This file contains low level display handling: headers and defines.
//
//----------------------------------------------------------------------------
// @Date          15/05/2009 11.45.26
//
//****************************************************************************


#ifndef HD44780_INC
#define HD44780_INC

#include "Arduino.h"

// commands
#define LCD_CLEARDISPLAY 		0x01
#define LCD_RETURNHOME 			0x02
#define LCD_ENTRYMODESET 		0x04
#define LCD_DISPLAYCONTROL 		0x08
#define LCD_CURSORSHIFT 		0x10
#define LCD_FUNCTIONSET 		0x20
#define LCD_SETCGRAMADDR 		0x40
#define LCD_SETDDRAMADDR 		0x80

// flags for display entry mode
#define LCD_ENTRYRIGHT 			0x00
#define LCD_ENTRYLEFT 			0x02
#define LCD_ENTRYSHIFTINCREMENT 0x01
#define LCD_ENTRYSHIFTDECREMENT 0x00

// flags for display on/off control
#define LCD_DISPLAYON 			0x04
#define LCD_DISPLAYOFF 			0x00
#define LCD_CURSORON 			0x02
#define LCD_CURSOROFF 			0x00
#define LCD_BLINKON 			0x01
#define LCD_BLINKOFF 			0x00

// flags for display/cursor shift
#define LCD_DISPLAYMOVE 		0x08
#define LCD_CURSORMOVE 			0x00
#define LCD_MOVERIGHT 			0x04
#define LCD_MOVELEFT 			0x00

// flags for function set
#define LCD_8BITMODE 			0x10
#define LCD_4BITMODE 			0x00
#define LCD_2LINE 				0x08
#define LCD_1LINE 				0x00
#define LCD_5x10DOTS 			0x04
#define LCD_5x8DOTS 			0x00


void LCDhome(void);
void LCDclear(void);
void LCDwriteString(char *string);
void LCDwriteChar(char pchar);
void LCDinitialize(void);
void LCDgoToPos(uint8_t line, uint8_t pchar);		   // connected display is 4 line x 20 chars
void LCDdefineChar(uint8_t charNo, uint8_t data[8]);   // 3 most significative bits of character data are truncated
void LCDdispON(void);
void LCDdispOFF(void);
void LCDtest(void);

#endif
