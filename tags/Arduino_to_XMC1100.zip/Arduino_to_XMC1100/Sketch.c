#include "Arduino.h"

//****************************************************************************
// 							       ARDUINO SKETCH
//****************************************************************************
#include "HD44780.h"


// the setup routine runs once when you press reset:
void setup()  {

	LCDinitialize();
	LCDclear();
	LCDgoToPos(2,2);
	LCDwriteString("Infineon Tech. AG");

	delay(1000);
	LCDclear();
	LCDtest();

	LCDgoToPos(1,4);
	LCDwriteString("Arduino-to-XMC");
	LCDgoToPos(2,4);
	LCDwriteString("Ready to GO !!");
	delay(1000);
}

// the loop routine runs over and over again forever:
void loop()  {
	delay(1000);
}

//****************************************************************************
// 							       END OF FILE
//****************************************************************************

