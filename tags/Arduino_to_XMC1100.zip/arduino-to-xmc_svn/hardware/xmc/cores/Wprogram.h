/*
 * Wprogram.h
 *
 *  Wrapper for Arduino.h for older libraries
 */

#ifndef WPROGRAM_H_
#define WPROGRAM_H_

#define _STDBOOL_H

#include "Arduino.h"

#endif /* WPROGRAM_H_ */
